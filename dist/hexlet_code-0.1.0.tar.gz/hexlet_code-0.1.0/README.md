### Hexlet tests and linter status:
[![Actions Status](https://github.com/viktoriyadzhoruhova/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/viktoriyadzhoruhova/python-project-49/actions)
<a href="https://codeclimate.com/github/viktoriyadzhoruhova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9acf1f80542720ebb529/maintainability" /></a>
## Brain-even asciinema

[![asciicast](https://asciinema.org/a/l40Lrk3midkLmNEOmgZErGnY7)]
